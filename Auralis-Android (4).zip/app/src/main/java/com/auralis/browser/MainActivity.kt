package com.auralis.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.*
import android.widget.FrameLayout
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var ui: WebView
    private lateinit var web: WebView

    inner class Bridge {
        @JavascriptInterface fun show(url: String) = runOnUiThread {
            if (web.url != url) web.loadUrl(url)
            web.visibility = View.VISIBLE
        }
        @JavascriptInterface fun hide() = runOnUiThread { web.visibility = View.GONE }
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val root = FrameLayout(this)
        ui = WebView(this); web = WebView(this)
        root.addView(ui, FrameLayout.LayoutParams(-1, -1))
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.topMargin = (78 * d).toInt(); lp.bottomMargin = (92 * d).toInt()
        root.addView(web, lp)
        web.visibility = View.GONE
        setContentView(root)

        ui.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = true; allowUniversalAccessFromFileURLs = true
        }
        ui.addJavascriptInterface(Bridge(), "Native")
        ui.loadUrl("file:///android_asset/index.html")

        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: ""
                return !(s == "http" || s == "https")
            }
            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) = nav(url, "")
            override fun onPageFinished(v: WebView, url: String) = nav(url, v.title ?: "")
        }
        var custom: View? = null
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                custom = v; root.addView(v, FrameLayout.LayoutParams(-1, -1))
            }
            override fun onHideCustomView() {
                custom?.let { root.removeView(it) }; custom = null
            }
        }
        web.setDownloadListener { url, ua, cd, mime, _ ->
            val r = DownloadManager.Request(Uri.parse(url))
            r.setMimeType(mime); r.addRequestHeader("User-Agent", ua)
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
        }
    }

    private fun nav(url: String, title: String) {
        ui.evaluateJavascript("window.onNav&&onNav(${JSONObject.quote(url)},${JSONObject.quote(title)})", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.visibility == View.VISIBLE && web.canGoBack()) { web.goBack(); return }
        ui.evaluateJavascript("(function(){var t=T();return !!(t.url||t.sq)})()") { r ->
            if (r == "true") ui.evaluateJavascript("back()", null) else finish()
        }
    }
}
